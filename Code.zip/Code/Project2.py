from collections import defaultdict
import sys
import time
import pandas as pd
from Dykstra import dGraph
import util as u



###-------------Dykstra---------------###
u.printDykstra()
print()
print()
###------------Kruskal----------------###
u.printKruskal()
print()
print()
###-----------Connected---------------###
u.printConnected()